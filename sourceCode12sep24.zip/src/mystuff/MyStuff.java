package mystuff;

public class MyStuff {
}
